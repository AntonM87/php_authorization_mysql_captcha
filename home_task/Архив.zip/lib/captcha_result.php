<?php

require_once 'Captcha_class.php';

Captcha_class::generator();
